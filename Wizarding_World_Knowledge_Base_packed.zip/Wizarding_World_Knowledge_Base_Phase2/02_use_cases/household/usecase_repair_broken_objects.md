---
id: "USECASE_REPAIR_BROKEN_OBJECTS"
name_zh: "修復破損物品"
name_en: "Repair Broken Objects"
aliases: ["修理物品", "修復損壞物件", "把破掉的東西修好"]
category: "household"
intent_keywords: ["修理", "修復", "破損", "損壞", "repair", "fix broken object", "mend"]
required_effects: ["repair"]
optional_effects: []
related_spell_ids: ["SPELL_REPARO"]
status: "verified"
---

# Overview
使用者希望使破損或故障的物品恢復原有結構或功能。

## Typical Scenarios
- 修復破裂、斷裂或損壞的日常物品。

## Required Effects
- `repair`

## Retrieval Concepts
修復咒、修補、物件修復、repair charm、Reparo。

## Notes
不應假設所有損壞、缺失零件或不可逆破壞都能由同一修復咒解決。
