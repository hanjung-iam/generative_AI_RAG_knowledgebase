---
id: "USECASE_CHANGE_OBJECT_COLOR"
name_zh: "改變物品顏色"
name_en: "Change Object Color"
aliases: ["改變顏色", "替物品換色", "讓物品變色"]
category: "household"
intent_keywords: ["變色", "顏色轉換", "改變物件顏色", "change color", "recolor object"]
required_effects: ["transformation"]
optional_effects: []
related_spell_ids: ["SPELL_COLOVARIA"]
status: "verified"
---

# Overview
使用者希望改變物品或目標的顏色，以達到外觀調整或辨識需求。

## Typical Scenarios
- 將物品改成另一種顏色
- 調整物件外觀色彩。

## Required Effects
- `transformation`

## Retrieval Concepts
變色咒、顏色轉換、Colovaria、color-changing charm。

## Notes
需區分改變顏色與改變材質、形狀或尺寸。
