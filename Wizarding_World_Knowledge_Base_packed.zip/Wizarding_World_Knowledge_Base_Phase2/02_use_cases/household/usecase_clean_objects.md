---
id: "USECASE_CLEAN_OBJECTS"
name_zh: "清潔物品"
name_en: "Clean Objects"
aliases: ["清理物品", "去除污垢", "清潔表面", "清除液體"]
category: "household"
intent_keywords: ["清潔", "打掃", "去污", "擦拭", "清除液體", "clean", "remove dirt", "cleaning charm"]
required_effects: ["other"]
optional_effects: []
related_spell_ids: ["SPELL_SCOURGIFY", "SPELL_TERGEO"]
status: "verified"
---

# Overview
使用者希望清除物品或表面的污垢、髒污或不需要的殘留物，使其恢復乾淨狀態。

## Typical Scenarios
- 清潔物品表面
- 清除污漬或殘留物
- 子情境包括從物品表面移除液體。

## Required Effects
- `other`

## Retrieval Concepts
清潔咒、去污、液體移除、cleaning、scouring、tergeo。

## Notes
依使用者決策，清潔與液體移除合併為同一 Use Case；液體移除是子情境。Functional Effects 字典沒有 cleaning，故 required_effects 使用 other。
