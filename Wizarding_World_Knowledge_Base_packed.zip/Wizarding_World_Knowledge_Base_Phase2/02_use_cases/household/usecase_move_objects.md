---
id: "USECASE_MOVE_OBJECTS"
name_zh: "移動物品"
name_en: "Move Objects"
aliases: ["移動物品", "搬運物件", "讓物品自己移動", "移動家具"]
category: "household"
intent_keywords: ["搬運", "移動", "物件移動", "漂浮移動", "move objects", "move items", "object movement"]
required_effects: ["object_movement"]
optional_effects: ["levitation", "summoning"]
related_spell_ids: ["SPELL_WINGARDIUM_LEVIOSA", "SPELL_ACCIO", "SPELL_PIERTOTUM_LOCOMOTOR"]
status: "verified"
external_candidate_ids: ["EXTSPELL_LOCOMOTOR"]
---

# Overview
使用者希望將物品從目前位置移動到另一位置，可能透過漂浮、召回或使物件動起來等不同魔法機制完成。

## Typical Scenarios
- 將物品搬到另一處
- 移動較重物品
- 讓特定物件自行移動或執行動作。

## Required Effects
- `object_movement`

## Optional / Supporting Effects
- `levitation`
- `summoning`

## Retrieval Concepts
物件移動、漂浮、召喚、物件動畫、object locomotion。

## Notes
採廣義目標分類：不同魔法機制保留在關聯層。Wingardium Leviosa 偏向漂浮控制；Accio 是召回；Piertotum Locomotor 專門使雕像／盔甲等物件活化，不是一般搬運咒。Locomotor 另列外部候選。
