---
id: "USECASE_CHANGE_OBJECT_SIZE"
name_zh: "改變物品大小"
name_en: "Change Object Size"
aliases: ["放大物品", "縮小物品", "改變物件尺寸"]
category: "household"
intent_keywords: ["放大", "縮小", "尺寸", "大小", "enlarge", "shrink", "resize object"]
required_effects: ["transformation"]
optional_effects: []
related_spell_ids: ["SPELL_ENGORGIO", "SPELL_REDUCIO"]
status: "verified"
---

# Overview
使用者希望改變物品的體積或尺寸，使其變大或變小。

## Typical Scenarios
- 放大物件以便使用
- 縮小物件以便攜帶或收納。

## Required Effects
- `transformation`

## Retrieval Concepts
放大咒、縮小咒、尺寸變化、engorgement、reduction。

## Notes
應區分尺寸改變與內部空間擴充；後者屬於儲存容器準備情境。
