---
id: "USECASE_DUPLICATE_OBJECTS"
name_zh: "複製物品"
name_en: "Duplicate Objects"
aliases: ["複製物品", "製作物件副本", "讓物品變成兩份"]
category: "household"
intent_keywords: ["複製", "複製品", "物件副本", "duplicate object", "copy an item", "duplication charm"]
required_effects: ["transformation"]
optional_effects: []
related_spell_ids: ["SPELL_GEMINIO"]
status: "verified"
---

# Overview
使用者希望產生與原物品相同或近似的複本，以增加可用物品數量。

## Typical Scenarios
- 將單一物件複製成多個副本
- 取得同一物品的複製品。

## Required Effects
- `transformation`

## Retrieval Concepts
複製咒、物件複製、Geminio、duplication。

## Notes
Gemino Curse 是與 Geminio 相關的特殊／詛咒形式，僅記錄為相關形式，不建立獨立 Spell 紀錄，也不將一般複製與無限複製混為一談。
