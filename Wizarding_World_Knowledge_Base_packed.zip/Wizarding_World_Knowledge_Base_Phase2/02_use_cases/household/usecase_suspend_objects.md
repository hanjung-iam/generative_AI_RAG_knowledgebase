---
id: "USECASE_SUSPEND_OBJECTS"
name_zh: "使物品懸浮"
name_en: "Suspend Objects"
aliases: ["讓物品懸浮", "使物品漂浮", "懸掛物品", "讓東西離開地面"]
category: "household"
intent_keywords: ["懸浮", "漂浮", "懸掛", "離開地面", "suspend object", "levitate object", "floating object"]
required_effects: ["suspension"]
optional_effects: ["levitation"]
related_spell_ids: ["SPELL_WINGARDIUM_LEVIOSA"]
status: "verified"
---

# Overview
使用者希望使物品離開支撐面並維持懸浮狀態，以便暫時懸置或控制其位置。

## Typical Scenarios
- 使物品漂浮在空中
- 暫時讓物品離開地面或桌面。

## Required Effects
- `suspension`

## Optional / Supporting Effects
- `levitation`

## Retrieval Concepts
懸浮、漂浮、levitation、suspension、Wingardium Leviosa。

## Notes
已將原 ID USECASE_HANG_OBJECTS 更名。此 Use Case 不等同於把物品固定在牆面或永久懸掛；Locomotor 是移動物件，不列為此情境正式關聯；Levicorpus 作用對象是人。
