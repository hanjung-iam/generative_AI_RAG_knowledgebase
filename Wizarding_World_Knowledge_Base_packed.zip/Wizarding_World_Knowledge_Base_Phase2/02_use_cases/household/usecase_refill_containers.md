---
id: "USECASE_REFILL_CONTAINERS"
name_zh: "補充容器內容物"
name_en: "Refill Containers"
aliases: ["替容器補充液體", "把杯子裝滿", "補充水或飲料"]
category: "household"
intent_keywords: ["補充", "裝滿", "容器", "液體", "refill", "fill a container", "top up"]
required_effects: ["other"]
optional_effects: ["water_generation"]
related_spell_ids: ["SPELL_REFILLING_CHARM", "SPELL_AGUAMENTI"]
status: "verified"
---

# Overview
使用者希望將容器中的內容物補充至所需量，尤其是重新填滿容器。

## Typical Scenarios
- 補滿杯子或其他容器
- 在需要液體時補充容器內容物。

## Required Effects
- `other`

## Optional / Supporting Effects
- `water_generation`

## Retrieval Concepts
補充咒、裝滿容器、液體生成、Refilling Charm、Aguamenti。

## Notes
Refilling Charm 是一般補充容器的主要候選；Aguamenti 僅能作為生成水的特定情境候選，不應泛化成補充所有液體。
