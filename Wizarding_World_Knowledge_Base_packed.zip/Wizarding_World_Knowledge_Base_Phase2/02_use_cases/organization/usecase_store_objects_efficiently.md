---
id: "USECASE_STORE_OBJECTS_EFFICIENTLY"
name_zh: "有效率地收納物品"
name_en: "Store Objects Efficiently"
aliases: ["整理物品", "收納行李", "快速打包", "把東西放進箱子"]
category: "organization"
intent_keywords: ["收納", "整理", "打包", "行李", "快速整理", "pack belongings", "organize items", "store objects"]
required_effects: ["other"]
optional_effects: ["object_movement", "transformation"]
related_spell_ids: ["SPELL_REDUCIO"]
status: "verified"
external_candidate_ids: ["EXTSPELL_LOCOMOTOR", "EXTSPELL_PACK"]
---

# Overview
使用者希望將多件物品快速整理、集中並收納至指定空間或容器，以提高收納效率。

## Typical Scenarios
- 將散落物品收進行李箱
- 整理房間或旅行用品
- 將物品集中至收納位置。

## Required Effects
- `other`

## Optional / Supporting Effects
- `object_movement`
- `transformation`

## Retrieval Concepts
收納、打包、整理行李、Pack、object movement、size reduction。

## Notes
Pack 是外部候選，原作情境可見但施法咒語是否為 Pack 並不確定；Locomotor 為外部輔助候選；Reducio 是推論性輔助用途，並非專用收納咒。
