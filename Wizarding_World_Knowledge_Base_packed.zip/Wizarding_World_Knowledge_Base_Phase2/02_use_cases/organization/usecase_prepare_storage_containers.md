---
id: "USECASE_PREPARE_STORAGE_CONTAINERS"
name_zh: "準備儲存容器"
name_en: "Prepare Storage Containers"
aliases: ["擴充容器容量", "讓包包內部變大", "準備大容量收納空間"]
category: "organization"
intent_keywords: ["擴充空間", "容器容量", "收納容量", "延伸咒", "expand container", "increase storage capacity", "extension charm"]
required_effects: ["transformation"]
optional_effects: ["other"]
related_spell_ids: []
status: "verified"
external_candidate_ids: ["EXTSPELL_UNDETECTABLE_EXTENSION_CHARM"]
---

# Overview
使用者希望在不明顯改變容器外部尺寸的情況下，增加其內部可用空間，以便容納更多物品。

## Typical Scenarios
- 擴充行李箱、帳篷或袋子的內部空間
- 準備具有大容量的儲存容器。

## Required Effects
- `transformation`

## Optional / Supporting Effects
- `other`

## Retrieval Concepts
無痕伸展咒、延伸咒、內部空間擴充、Undetectable Extension Charm、Capacious extremis。

## Notes
Undetectable Extension Charm 為外部候選，不在 50 筆正式 Spell 中。此情境是改變容器內部容量，不等同於將物品本身縮小。
