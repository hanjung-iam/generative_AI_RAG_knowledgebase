---
id: "USECASE_SILENCE_UNWANTED_SOUNDS"
name_zh: "消除不必要的聲音"
name_en: "Silence Unwanted Sounds"
aliases: ["讓物品或目標安靜", "消除聲音", "避免被聽見", "隔絕談話聲"]
category: "daily_life"
intent_keywords: ["消音", "安靜", "靜音", "聲音干擾", "silence", "mute", "suppress sound", "conceal conversation"]
required_effects: ["other"]
optional_effects: []
related_spell_ids: ["SPELL_SILENCIO", "SPELL_MUFFLIATO"]
status: "verified"
---

# Overview
使用者希望降低或消除特定聲音，或避免附近的人清楚聽見談話內容。

## Typical Scenarios
- 使目標不再發出聲音
- 在周遭聽者耳中製造干擾聲，以隱藏談話內容。

## Required Effects
- `other`

## Retrieval Concepts
消音、聲音抑制、談話隱蔽、Silencio、Muffliato。

## Notes
Silencio 是直接消音；Muffliato 是在附近人的耳中產生嗡嗡聲以遮蔽談話，兩者機制不同。Quietus 僅記為 Sonorus 的反向關係，不列為此情境候選。
