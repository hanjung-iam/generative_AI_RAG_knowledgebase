---
id: "USECASE_AMPLIFY_VOICE"
name_zh: "放大聲音以便溝通"
name_en: "Amplify Voice for Communication"
aliases: ["放大聲音", "讓聲音傳得更遠", "提高音量"]
category: "daily_life"
intent_keywords: ["放大聲音", "提高音量", "遠距溝通", "amplify voice", "loud voice", "communication"]
required_effects: ["communication"]
optional_effects: []
related_spell_ids: ["SPELL_SONORUS"]
status: "verified"
---

# Overview
使用者希望提高自己的聲音音量，使訊息能傳達給較遠距離或較大範圍的聽眾。

## Typical Scenarios
- 在大型空間、戶外或人群中讓他人聽見說話內容。

## Required Effects
- `communication`

## Retrieval Concepts
聲音放大、擴音、溝通、Sonorus、amplification charm。

## Notes
Quietus 是 Sonorus 的反向／解除關係，不是放大聲音的候選 Spell。
