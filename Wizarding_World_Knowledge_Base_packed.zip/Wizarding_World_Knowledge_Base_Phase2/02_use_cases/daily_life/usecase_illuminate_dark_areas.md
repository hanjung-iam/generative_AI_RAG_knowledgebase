---
id: "USECASE_ILLUMINATE_DARK_AREAS"
name_zh: "在黑暗中照明"
name_en: "Illuminate Dark Areas"
aliases: ["照亮黑暗", "提供光源", "讓魔杖發光", "黑暗中看清楚"]
category: "daily_life"
intent_keywords: ["照明", "黑暗", "光源", "看清楚", "wand light", "light up", "dark area"]
required_effects: ["illumination"]
optional_effects: []
related_spell_ids: ["SPELL_LUMOS"]
status: "verified"
external_candidate_ids: ["EXTSPELL_LUMOS_MAXIMA"]
---

# Overview
使用者希望在光線不足或完全黑暗的環境中取得足夠照明，以辨識周遭環境、閱讀或安全移動。

## Typical Scenarios
- 例如在走廊、森林、房間或夜間行走時照亮前方
- 在昏暗環境中閱讀。

## Required Effects
- `illumination`

## Retrieval Concepts
照明、魔杖光、光源、黑暗環境、wand-lighting charm。

## Notes
Lumos 是正式 50 筆 Spell 中的主要關聯。Lumos Maxima 僅作為電影／外部候選記錄，不建立正式 Spell 檔案。
