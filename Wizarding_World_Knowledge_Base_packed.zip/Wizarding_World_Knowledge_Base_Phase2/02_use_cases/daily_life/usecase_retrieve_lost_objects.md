---
id: "USECASE_RETRIEVE_LOST_OBJECTS"
name_zh: "取回遠處物品"
name_en: "Retrieve Distant Objects"
aliases: ["召回物品", "把遠處物品拿過來", "取回東西", "召喚物品"]
category: "daily_life"
intent_keywords: ["召回", "取回", "遠處物品", "召喚", "summon", "retrieve", "bring an object here"]
required_effects: ["summoning"]
optional_effects: []
related_spell_ids: ["SPELL_ACCIO"]
status: "verified"
---

# Overview
使用者希望不必親自走到物品所在位置，即可將指定物品召回身邊。

## Typical Scenarios
- 召回放在遠處、視線外或不易直接取得的物品
- 取回指定物件。

## Required Effects
- `summoning`

## Retrieval Concepts
召喚咒、召回物品、遠距取物、Summoning Charm、Accio。

## Notes
需確認目標物品可被召喚且不受阻礙；Accio 不應被泛化為任意傳送。
