---
id: "USECASE_UNLOCK_LOCKED_DOORS"
name_zh: "開啟上鎖的門"
name_en: "Unlock Locked Doors"
aliases: ["開鎖", "打開鎖住的門", "解除門鎖"]
category: "daily_life"
intent_keywords: ["開鎖", "門鎖", "上鎖", "unlock", "locked door", "open a lock"]
required_effects: ["unlocking"]
optional_effects: []
related_spell_ids: ["SPELL_ALOHOMORA"]
status: "verified"
---

# Overview
使用者希望解除一般門鎖或鎖具的鎖定狀態，以開啟原本上鎖的門或物件。

## Typical Scenarios
- 打開上鎖的門、箱子或其他可由鎖具保護的物件。

## Required Effects
- `unlocking`

## Retrieval Concepts
開鎖咒、解除鎖定、lock opening、Alohomora。

## Notes
不能假設 Alohomora 能解除所有魔法封鎖或特殊防護；情境需區分一般鎖與魔法保護。
