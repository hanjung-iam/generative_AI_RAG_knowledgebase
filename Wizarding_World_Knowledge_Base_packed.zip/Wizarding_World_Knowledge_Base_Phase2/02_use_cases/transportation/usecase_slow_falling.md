---
id: "USECASE_SLOW_FALLING"
name_zh: "減緩墜落速度"
name_en: "Slow a Falling Object or Person"
aliases: ["減緩墜落", "讓墜落變慢", "降低下墜速度", "減速墜落"]
category: "transportation"
intent_keywords: ["減緩墜落", "減速", "下墜", "緩衝下降", "slow falling", "brake a fall", "decelerate"]
required_effects: ["other"]
optional_effects: []
related_spell_ids: ["SPELL_ARRESTO_MOMENTUM"]
status: "verified"
---

# Overview
使用者希望降低正在墜落或快速移動的目標速度，以減輕撞擊或避免高速落地。

## Typical Scenarios
- 使墜落中的人或物體減速
- 在目標落地前降低其動量。

## Required Effects
- `other`

## Retrieval Concepts
制動咒、減速、墜落減速、Arresto Momentum、braking charm。

## Notes
Cushioning Charm 著重於提供柔軟緩衝／減輕落地衝擊，不等同於直接減緩墜落速度，因此不建立正式關聯。
