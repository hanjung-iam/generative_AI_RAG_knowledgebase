---
id: "USECASE_TRANSFORM_STAIRS_INTO_SLIDE"
name_zh: "將樓梯變成滑梯"
name_en: "Transform Stairs into a Slide"
aliases: ["把樓梯變成滑梯", "讓階梯變成滑道", "改變樓梯形狀"]
category: "transportation"
intent_keywords: ["樓梯", "滑梯", "滑道", "形狀轉換", "stairs into slide", "sliding spell", "transform stairs"]
required_effects: ["transformation"]
optional_effects: []
related_spell_ids: ["SPELL_GLISSEO"]
status: "verified"
---

# Overview
使用者希望改變樓梯或階梯的形態，使其成為可滑行的斜面或滑道。

## Typical Scenarios
- 將一段樓梯轉變成平滑滑道，讓人沿斜面滑下。

## Required Effects
- `transformation`

## Retrieval Concepts
滑行咒、樓梯轉換、Glisseo、sliding spell。

## Notes
此為具體的環境形態轉換情境，不應泛化成所有地形或建築改造。
