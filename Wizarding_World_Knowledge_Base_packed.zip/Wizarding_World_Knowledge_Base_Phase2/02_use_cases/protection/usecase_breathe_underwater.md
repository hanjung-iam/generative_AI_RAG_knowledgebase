---
id: "USECASE_BREATHE_UNDERWATER"
name_zh: "水下呼吸"
name_en: "Breathe Underwater"
aliases: ["在水下呼吸", "水下生存", "讓頭部有空氣罩"]
category: "protection"
intent_keywords: ["水下", "呼吸", "水下防護", "泡泡頭", "underwater breathing", "breathe underwater", "bubble head"]
required_effects: ["protection"]
optional_effects: []
related_spell_ids: ["SPELL_BUBBLE_HEAD_CHARM"]
status: "verified"
---

# Overview
使用者希望在水下維持可呼吸的空氣環境，使頭部周圍保有可供呼吸的空氣。

## Typical Scenarios
- 潛入水中時在頭部周圍形成空氣泡
- 在水下活動期間維持呼吸條件。

## Required Effects
- `protection`

## Retrieval Concepts
水下呼吸、泡泡頭咒、空氣罩、Bubble-Head Charm。

## Notes
已將原 ID USECASE_PROTECT_HEAD_UNDERWATER 更名。Impervius 主要是防水／防濕效果，不能等同於提供水下呼吸空氣，因此不建立正式關聯。
