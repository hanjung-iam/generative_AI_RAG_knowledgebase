---
id: "USECASE_IMMOBILIZE_TARGETS"
name_zh: "限制目標行動"
name_en: "Immobilize Targets"
aliases: ["使目標無法行動", "定身", "限制行動", "束縛對手", "阻止目標移動"]
category: "protection"
intent_keywords: ["定身", "束縛", "凍結", "限制行動", "immobilize", "bind target", "stop movement", "body bind"]
required_effects: ["binding"]
optional_effects: []
related_spell_ids: ["SPELL_PETRIFICUS_TOTALUS", "SPELL_IMPEDIMENTA", "SPELL_IMMOBULUS"]
status: "verified"
external_candidate_ids: ["EXTSPELL_LOCOMOTOR_MORTIS", "EXTSPELL_INCARCEROUS"]
---

# Overview
使用者希望暫時限制目標的行動能力，使其無法自由移動、追擊或採取行動。

## Typical Scenarios
- 使目標全身僵直
- 減慢或阻止目標前進
- 使特定目標暫時靜止
- 以繩索等方式束縛目標。

## Required Effects
- `binding`

## Retrieval Concepts
定身咒、束縛咒、凍結咒、行動限制、body-bind、impediment。

## Notes
不同咒語的限制方式與程度不同：Petrificus Totalus 為全身束縛；Impedimenta 偏向阻礙／減速；Immobulus 偏向凍結目標；Locomotor Mortis 與 Incarcerous 僅列外部候選。Levicorpus、Tarantallegra 不屬於一般限制行動候選。
