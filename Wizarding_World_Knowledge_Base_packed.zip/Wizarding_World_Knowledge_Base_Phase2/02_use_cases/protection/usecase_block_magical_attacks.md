---
id: "USECASE_BLOCK_MAGICAL_ATTACKS"
name_zh: "阻擋魔法攻擊"
name_en: "Block Magical Attacks"
aliases: ["施展防護罩", "擋下咒語", "防禦魔法攻擊"]
category: "protection"
intent_keywords: ["防護", "護盾", "阻擋咒語", "魔法攻擊", "shield", "block spells", "magical defense"]
required_effects: ["protection"]
optional_effects: []
related_spell_ids: ["SPELL_PROTEGO"]
status: "verified"
---

# Overview
使用者希望建立防護效果，以阻擋或偏轉來襲的魔法攻擊。

## Typical Scenarios
- 面對對手施放的咒語時建立防護
- 在戰鬥中保護自己或他人。

## Required Effects
- `protection`

## Retrieval Concepts
防護咒、護盾、Protego、shield charm、block magical attack。

## Notes
Protego 的防護能力不代表可抵擋所有種類、強度或特殊效果的魔法。
