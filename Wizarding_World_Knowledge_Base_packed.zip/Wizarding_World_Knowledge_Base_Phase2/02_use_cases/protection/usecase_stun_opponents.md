---
id: "USECASE_STUN_OPPONENTS"
name_zh: "使對手昏迷"
name_en: "Stun Opponents"
aliases: ["擊昏對手", "使目標昏厥", "昏迷咒"]
category: "protection"
intent_keywords: ["昏迷", "擊昏", "震昏", "stun", "knock unconscious", "Stunning Spell"]
required_effects: ["stunning"]
optional_effects: []
related_spell_ids: ["SPELL_STUPEFY"]
status: "verified"
---

# Overview
使用者希望以魔法攻擊使對手短暫失去意識或失去戰鬥能力。

## Typical Scenarios
- 在對抗中擊昏對手
- 使目標暫時失去意識或反應能力。

## Required Effects
- `stunning`

## Retrieval Concepts
昏擊咒、昏迷、Stupefy、Stunning Spell。

## Notes
Stupefy 的核心目標是使對象昏迷；不要與長時間定身或繩索束縛混為一談。
