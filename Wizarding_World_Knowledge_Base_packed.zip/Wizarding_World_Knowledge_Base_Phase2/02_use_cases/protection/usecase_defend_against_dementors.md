---
id: "USECASE_DEFEND_AGAINST_DEMENTORS"
name_zh: "防禦催狂魔"
name_en: "Defend Against Dementors"
aliases: ["抵禦催狂魔", "驅逐催狂魔", "保護自己免受催狂魔攻擊"]
category: "protection"
intent_keywords: ["催狂魔", "守護神", "防禦", "驅逐", "dementor", "patronus", "defend against dementors"]
required_effects: ["protection"]
optional_effects: []
related_spell_ids: ["SPELL_EXPECTO_PATRONUM"]
status: "verified"
---

# Overview
使用者希望抵禦催狂魔造成的恐懼與威脅，並使其遠離。

## Typical Scenarios
- 面對催狂魔時召喚守護神
- 以守護神作為防禦與驅離手段。

## Required Effects
- `protection`

## Retrieval Concepts
守護神咒、催狂魔防禦、Patronus Charm、Dementor defense。

## Notes
此情境具有特定威脅對象，不能泛化成所有黑魔法或一般攻擊的防護。
