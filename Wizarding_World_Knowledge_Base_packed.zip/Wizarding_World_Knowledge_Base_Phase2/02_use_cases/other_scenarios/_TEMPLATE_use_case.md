---
id: USECASE_REPLACE_WITH_ID
name_zh: "繁體中文情境名稱"
name_en: "English Use Case Name"
# name_ja: "日本語名"
# aliases: []
category: daily_life
intent_keywords: ["使用者可能說出的詞句"]
# target_objects: []
required_effects: ["effect_id"]
# related_spell_ids: []
status: draft
---

# Overview
描述使用者希望達成的具體目標，不預設特定魔法必然能完成。

## Typical Scenarios
列出自然語言說法、口語表達與同義詞。

## Required Effects
拆解完成目標所需的效果，可參照 functional_effects 字典；複合需求可包含多個效果。

## Retrieval Concepts
列出適合檢索的中英文概念、同義詞或動作。

## Notes
記錄情境邊界、子任務，以及容易混淆但應分開處理的需求。
