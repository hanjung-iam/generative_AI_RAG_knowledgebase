# Knowledge Schema Specification
Version: 2.1 — Use Case and Relationship extension

## 1. Core entities
- **Spell**：具名魔法的身份、分類、效果、施法資訊與來源。
- **Use Case**：使用者希望達成的具體目標。
- **Spell–Use Case Relationship**：魔法與情境的關聯及其證據性質。

## 2. Spell record
每個 Spell 一個 Markdown 檔，使用 YAML Front Matter。

| Field | Type | Required | Description |
|---|---|---:|---|
| `id` | string | Yes | 唯一穩定 ID：`SPELL_UPPER_SNAKE_CASE` |
| `name_en` | string | Yes | 英文主要名稱 |
| `name_zh` / `name_ja` | string | No | 繁中／日文名稱 |
| `aliases` | array[string] | No | 同一實體別名；多語言主要名稱由 translation mapping 管理 |
| `incantation` | string | No | 已知施法咒語；未知或未揭露則省略 |
| `magic_classification` | enum | Yes | 單一主要魔法性質分類 |
| `functional_effects` | array[enum] | Yes | 至少一項有證據支持的功能效果 |
| `application_domains` | array[enum] | No | 高層級應用領域；不要求逐項證據狀態 |
| `difficulty` | enum | Yes | simple / medium / hard，人工標記 |
| `restriction` | enum | Yes | general / restricted，人工標記 |
| `classification_notes` | string | No | 分類判斷說明 |
| `classification_evidence` | array[object] | No | 分類依據及來源 |
| `application_domain_evidence` | array[object] | No | Legacy field；新紀錄不要求，若保留則僅作補充資訊 |
| `target` | string or array | No | 施法對象 |
| `wand_movement` | string | No | 有來源才填 |
| `casting_requirements` | string or array | No | 有來源才填 |
| `magical_effects` | array[object] | Yes | 效果描述、證據標籤、reference IDs |
| `limitations` / `side_effects` | array[string] | No | 有證據才填 |
| `counter_spells` | array[string] | No | 反制魔法 ID 或名稱 |
| `variant_of` | string | No | 明確變體的父項 Spell ID |
| `related_spell_ids` | array[string] | No | 其他相關魔法 ID；需說明關係 |
| `entity_resolution_notes` | string | No | 實體識別或來源衝突備註 |
| `references` | array[object] | Yes | 可追溯來源 |
| `taxonomy_version` | string | Yes | 使用的分類版本，例如 `1.0` |
| `status` | enum | Yes | draft / verified / deprecated |

### 2.1 functional_effects evidence
建議在每個效果物件保留：
```yaml
functional_effects:
  - effect_id: levitation
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS]
```
`functional_effects` 字典只定義標籤意義；此處記錄該魔法是否確實具有該效果。

### 2.2 application_domains
`application_domains` 僅作高層級分類標籤，不要求逐項 `canon` / `inferred` 證據欄位。具體情境證據由 Spell–Use Case Relationship 管理，避免同一證據在兩層重複維護。

### 2.3 references
```yaml
references:
  - reference_id: REF_WBJP_SPELLS
    url: "https://www.warnerbros.co.jp/harrypotter/feature/spells-and-charms/"
    source_name: "Warner Bros. Japan — Spells and Charms"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "YYYY-MM-DD"
```
`source_tier`: official / supplementary / other。

## 3. Use Case record
每個具體使用者目標一個 Markdown 檔。

| Field | Type | Required | Description |
|---|---|---:|---|
| `id` | string | Yes | `USECASE_UPPER_SNAKE_CASE` |
| `name_zh` | string | Yes | 繁中名稱 |
| `name_en` | string | Yes | 英文名稱 |
| `name_ja` | string | No | 日文名稱 |
| `aliases` | array[string] | No | 口語表達與同義詞 |
| `category` | enum | Yes | Use Case taxonomy |
| `intent_keywords` | array[string] | Yes | 自然語言檢索詞 |
| `target_objects` | array[string] | No | 情境中的對象 |
| `required_effects` | array[string] | Yes | 完成目標所需效果；可對照 functional effects |
| `optional_effects` | array[string] | No | 可協助完成目標的次要效果 |
| `related_spell_ids` | array[string] | No | 已建立正式關聯的 Spell ID；僅指向核心 Spell corpus |
| `external_candidate_ids` | array[string] | No | 指向 external_spell_candidates.json 的 EXTSPELL_ 候選 ID，不是 Spell entity ID |
| `references` | array[object] | No | 情境涉及外部事實時使用 |
| `status` | enum | Yes | draft / verified / deprecated |

Use Case 描述使用者目標，不預設特定魔法必然能完成。內文建議包含 Overview、Typical Scenarios、Required Effects、Retrieval Concepts、Notes。

## 4. Spell–Use Case Relationship
集中於 `03_relationships/spell_use_case_relationships.json`，JSON array。

| Field | Type | Required | Description |
|---|---|---:|---|
| `id` | string | Yes | 唯一關聯 ID |
| `spell_id` | string | Yes | Spell ID |
| `use_case_id` | string | Yes | Use Case ID |
| `application_type` | enum | Yes | canon / inferred |
| `role` | enum | Yes | primary / supporting / specialized；推薦角色，不代表證據性質 |
| `matching_conditions` | array[string] | Yes | 適用條件 |
| `evidence` | array[object] | Yes | 來源與推論依據 |
| `notes` | string | No | 補充 |
| `confidence` | enum | No | high / medium / low |

`canon` 必須有來源明確支持具體用途；`inferred` 必須寫出需求 → 所需效果 → 魔法已知效果的推論鏈。Confidence 不可取代 application_type。

## 5. ID and entity resolution
- Spell：`SPELL_UPPER_SNAKE_CASE`
- Use Case：`USECASE_UPPER_SNAKE_CASE`
- Relationship：`REL_` + unique identifier
- Reference：`REF_` + source identifier
- Translation / Alias 共用同一 Spell ID。
- Variant / Related 各自使用獨立 Spell ID。
- `variant_of` 僅用於有證據支持的變體關係；功能相似不足以建立 variant。
- ID 建立後不因翻譯或分類變更而修改。

## 6. Missing values
未知或未查證的選填欄位直接省略；不以空字串、null 或一律填 unknown。只有未知狀態本身有意義時，才使用明確狀態欄位。

## 7. RAG derived documents
原始 Markdown / JSON 是 source of truth。RAG 文件由 verified records 生成。每個 chunk 至少保留：
- `entity_id`
- `record_type`
- `status`
- `name_en` / available names / aliases
- `magic_classification`
- `functional_effects`
- `application_domains`
- `difficulty`
- `restriction`
- `application_type`（適用時）
- `reference_ids`

Spell、Use Case、Relationship 可分別建立文件，檢索後依 ID 合併。不可在 chunking 時丟失 canon / inferred 或 entity relation 資訊。

## 8. Minimum validation
1. ID 唯一且格式正確。
2. Spell 必填欄位齊全；enum 值必須存在於對應字典。
3. `magic_classification` 僅一個值；functional_effects 可多值。
4. 每個 functional effect 必須能解析至字典。
5. 每個 application domain 必須能解析至字典；不要求逐項 evidence。
6. verified records 必須有可追溯來源。
7. Relationship IDs 必須指向存在的 Spell / Use Case。
8. inferred 關聯必須提供 reasoning；Application Domains 不要求逐項 reasoning。
9. variant_of 必須指向存在的 Spell，且有來源支持變體關係。
10. 不可把推論用途寫成 canon 效果。
