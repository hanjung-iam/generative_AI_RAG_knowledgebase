# Entity Resolution & Variant Rules
Version: 1.0

## 1. Purpose
本規則判定兩個名稱是否指向同一個魔法實體，或是兩個不同但相關的魔法。目標是避免重複建檔、錯誤合併與關係遺失。

## 2. Relationship types

| Relationship | 定義 | ID policy |
|---|---|---|
| `translation` | 同一魔法在不同語言中的名稱 | 共用同一 Spell ID |
| `alias` | 同一魔法的別稱、拼寫變體或慣用稱呼 | 共用同一 Spell ID |
| `variant` | 具有獨立身份、名稱且可辨識差異的魔法變體 | 各自 ID；使用 `variant_of` |
| `related` | 不同魔法之間存在功能、用途、反制或設定關係，但不是變體 | 各自 ID；以 relationship record 連結 |

## 3. Decision procedure
1. **確認來源語境**：名稱出自哪個作品／媒介／版本？不要把遊戲、電影、小說或衍生作品的內容未經判斷混成同一來源層級。
2. **查詢既有 registry 與 translation mapping**：先檢查是否已登記。
3. **是否為翻譯名稱？** 若來源明確指向同一個魔法，使用同一 ID。
4. **是否為別稱或拼寫差異？** 若指向同一實體且無獨立魔法身份，加入 aliases。
5. **是否有獨立名稱及可辨識的魔法差異？** 若來源支持其為獨立魔法，建立新 ID。
6. **是否明確為某魔法的變體？** 有來源支持時建立 `variant_of`；只有效果相似時不可建立。
7. **證據不足？** 暫存 draft，記錄待確認問題，不要猜測合併或拆分。

## 4. Practical criteria

### Same entity: translation / alias
符合以下情況通常共用 ID：
- 官方或可靠來源將不同語言名稱對應至同一魔法。
- 只是拼寫、轉寫、大小寫或語言差異。
- 名稱不同但來源明確說明是同一魔法的別稱。
- 沒有證據顯示它是獨立施法或獨立魔法實體。

### Distinct entity: variant
建立不同 ID 的必要條件：
- 有獨立可辨識的名稱；且
- 來源支持它是獨立魔法，或是另一魔法的明確變體；且
- 具有可描述的設定、效果、施法或強度差異。

如僅有「名字看起來像強化版」或「效果似乎較強」的推測，不足以建立 variant 關係。

### Related but not variant
若兩個魔法效果相似、可用於相同 Use Case、互相反制，或在故事中有關聯，但沒有證據顯示它們是變體，則各自保留 ID，使用 `related` 關係。

## 5. Lumos / Lumos Maxima illustration
若採用的來源支持兩者是可區分的具名魔法，則分別建立：
- `SPELL_LUMOS`
- `SPELL_LUMOS_MAXIMA`

只有來源明確支持其變體關係時，才在 Lumos Maxima record 設定：
`variant_of: SPELL_LUMOS`

此範例是資料建模示範；正式登錄前仍須核對所選來源的具體描述。

## 6. Wingardium Leviosa / Accio illustration
兩者分別建立獨立 ID。即使都可能對「搬運物品」Use Case 有關聯，也不代表彼此是 variant：
- Wingardium Leviosa：漂浮效果
- Accio：召來效果

可分別連結同一 Use Case，但必須各自記錄其效果與應用證據。

## 7. Ambiguity and conflicting sources
- 保留原始名稱、來源 URL、媒介／版本、來源日期（若可得）。
- 若來源對實體身份或變體關係說法不一致，狀態維持 `draft`，在 `entity_resolution_notes` 說明差異。
- 不要將粉絲 Wiki 的推測提升為官方事實。
- 若日後確認兩筆紀錄為同一實體，選定 canonical ID，舊 ID 設為 deprecated 並保留 redirect / migration note；不可直接刪除。

## 8. Registry representation
`id_registry.json` 應保留 entity ID、canonical name、file path、status。`translation_mapping.json` 管理同一實體的多語言名稱與 aliases。Variant / Related 關係應記錄於 Spell record 或獨立關係資料，不以別名方式處理。

## 9. Review checklist
- [ ] 是否檢查過現有 ID？
- [ ] 是否確認來源媒介與版本？
- [ ] 是否有證據支持同一實體？
- [ ] 若建立 variant，是否有證據支持變體關係？
- [ ] 若只是效果相似，是否避免錯誤建立 variant？
- [ ] 不確定時是否保留 draft？
