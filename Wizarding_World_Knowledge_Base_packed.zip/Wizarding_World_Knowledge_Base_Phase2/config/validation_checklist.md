# Data Validation Checklist — Phase 2

## Spell identity
- [ ] ID 唯一且符合 `SPELL_UPPER_SNAKE_CASE`
- [ ] 已檢查 id_registry 與 translation_mapping
- [ ] Translation / Alias 共用 ID；Variant / Related 使用獨立 ID
- [ ] variant_of 有來源支持，不只是效果相似
- [ ] 不確定的實體關係維持 draft

## Taxonomy
- [ ] magic_classification 僅一個值，且存在於字典
- [ ] functional_effects 每個 effect_id 都存在於字典
- [ ] 每個功能效果有證據或明確推論紀錄
- [ ] application_domains 每個值都存在於字典
- [ ] 每個 application domain 有 canon / inferred evidence
- [ ] domain 不被當成具體 Use Case
- [ ] difficulty 僅 simple / medium / hard
- [ ] restriction 僅 general / restricted
- [ ] taxonomy_version 已填寫

## Spell record
- [ ] name_en、magic_classification、functional_effects、difficulty、restriction、taxonomy_version、references、status 齊全
- [ ] incantation、wand_movement、side_effects 等未知欄位已省略
- [ ] verified record 有可追溯來源

## Use Case
- [ ] ID 唯一且符合 `USECASE_UPPER_SNAKE_CASE`
- [ ] category 是 Use Case 分類，不是 magic_classification
- [ ] required_effects 使用功能效果概念或可映射到 effect_id
- [ ] 具體情境沒有被粗粒度 application_domains 取代

## Relationship
- [ ] Relationship ID 唯一
- [ ] spell_id、use_case_id 指向存在紀錄
- [ ] application_type 是 canon / inferred
- [ ] inferred 有推論鏈與未確認條件
- [ ] canon 有具體用途證據
- [ ] confidence 不取代 application_type

## Registry / indexes
- [ ] id_registry.json 已更新
- [ ] translation_mapping.json 已更新
- [ ] 對應 indexes 已更新
- [ ] deprecated 記錄保留遷移資訊


## Use Case / Relationship 2.1 Additions
- [ ] Use Case ID 唯一且符合 `USECASE_UPPER_SNAKE_CASE`。
- [ ] Use Case category 僅使用核准分類。
- [ ] `required_effects` 與 `optional_effects` 均可解析至 Functional Effects 字典。
- [ ] `related_spell_ids` 僅引用 50 筆正式 Spell。
- [ ] `external_candidate_ids` 僅引用 `external_spell_candidates.json` 中的 EXTSPELL_ ID。
- [ ] 正式關聯 `spell_id` 與 `use_case_id` 均存在。
- [ ] `application_type` 僅為 `canon` 或 `inferred`；`role` 僅為 `primary`、`supporting`、`specialized`。
- [ ] `canon` 有具體用途來源；`inferred` 有完整推論鏈。
- [ ] 外部候選不建立 Spell Markdown，也不出現在正式關聯 JSON。
- [ ] Index 與 ID Registry 與正式資料同步。
