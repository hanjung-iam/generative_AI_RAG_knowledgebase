# Category Definitions
Version: 2.1 — Phase 2 taxonomy + approved Use Case taxonomy

本文件是分類速查表；完整字典分別見 `magic_classification.json`、`functional_effects.json`、`application_domains.json`。

## 1. Magic classification
描述魔法性質／傳統類型，單一主要值：
- `charm`
- `jinx`
- `hex`
- `curse`
- `transfiguration`
- `other`
- `unclassified`

這是專案整理用 taxonomy，不宣稱為官方世界觀中完全互斥且固定的分類體系。防禦、治療、召喚、照明等通常屬功能或用途維度，不應直接混入此欄。

## 2. Functional effects
描述魔法實際產生的效果，可多選。標籤包括：
`levitation`, `object_movement`, `summoning`, `illumination`, `fire_generation`, `repair`, `unlocking`, `protection`, `healing`, `dispel`, `transformation`, `suspension`, `binding`, `stunning`, `concealment`, `communication`, `water_generation`, `other`。

每個效果必須有該魔法的證據或明確推論紀錄。

## 3. Application domains
描述高層級應用領域，可多選：
`daily_life`, `household`, `transportation`, `organization`, `combat`, `defense`, `healing`, `communication`, `exploration`, `education`, `repair_maintenance`, `other`。

Domain 是粗粒度標籤；具體使用者目標仍由 Use Case 表示。

## 4. Difficulty
`simple` / `medium` / `hard`，人工標記，非官方量化等級。對應原創角色特質啟發語氣：
- simple：Snape-inspired，簡潔、銳利、略帶諷刺。
- medium：McGonagall-inspired，嚴謹、條理、鼓勵。
- hard：Hermione-inspired，熱情、詳盡、知識豐富。

## 5. Restriction
`general` / `restricted`，人工標記。restricted 觸發額外警示層，與難度獨立。標記依據應記錄在來源或備註。

## 6. Evidence and status
- `canon`：來源明確支持效果或具體用途。
- `inferred`：由已知效果推導，來源未明確確認該用途。
- confidence：high / medium / low，僅表示推論強度。
- status：draft / verified / deprecated。

## 7. Use Case categories
Use Case 分類描述使用者希望達成的具體目標，與 Application Domains 分開管理。此版本核准分類為：
- `daily_life`：日常個人活動與一般生活需求。
- `household`：居家、物品處理與家務相關需求。
- `transportation`：移動、行進與交通情境。
- `protection`：防禦、保護與限制威脅的情境。
- `organization`：整理、收納與空間管理。
- `other_scenarios`：暫無合適分類的其他情境。

清潔、修復、照明、開鎖、溝通與變形等具體任務，不另設 Use Case Category；應由 Use Case 名稱與 Functional Effects 表達。