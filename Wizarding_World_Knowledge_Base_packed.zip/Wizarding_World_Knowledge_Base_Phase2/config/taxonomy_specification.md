# Multi-dimensional Taxonomy Specification
Version: 1.0

## 1. Design objective
分類系統必須同時回答五個不同問題：
- 這是什麼性質的魔法？ (`magic_classification`)
- 它實際產生什麼效果？ (`functional_effects`)
- 它可能在哪些高層級領域應用？ (`application_domains`)
- 專案如何評估其施展難度？ (`difficulty`)
- 專案是否要求額外限制警示？ (`restriction`)

前三個欄位不得互相替代；後兩者是專案管理標籤，不是魔法本體分類。

## 2. Taxonomy dimensions

### 2.1 magic_classification
- 單一主要分類；使用 `config/magic_classification.json` 中的 ID。
- 分類魔法性質／傳統類型，而非使用場景。
- 若無法可靠判定，使用 `unclassified`，並維持 `draft`。
- 不因魔法具有防禦、治療或照明用途，就直接把功能標籤當作魔法性質分類。

### 2.2 functional_effects
- 多值欄位；每個值必須來自 `functional_effects.json`。
- 描述可觀察或可合理界定的魔法效果，例如使物體漂浮、產生光線、解除魔法。
- 每個效果應能連結到來源證據，或在明確標記的推論資料中說明。
- 不要將應用場景（例如「晾衣服」）直接當作功能效果。

### 2.3 application_domains
- 多值欄位；使用 `application_domains.json`。
- 表示高層級應用領域，例如 household、defense、exploration。
- 是分類與篩選標籤，不等於原作明確展示的具體用途。
- 若某領域只是由效果推導，必須以 `application_domain_evidence` 標示 `inferred`，不得僅因標籤存在就當成 canon。

### 2.4 difficulty
- 單值：`simple` / `medium` / `hard`。
- 由維護者人工標記，供回答語氣與解說深度控制。
- 不是官方量化分級，不得由魔法分類或限制程度自動推導。

### 2.5 restriction
- 單值：`general` / `restricted`。
- 由維護者人工標記；若依據世界觀法律、制度或來源明確限制，需記錄依據。
- `restricted` 觸發額外警示層，不代表新增難度級別，也不必然等同於禁止提供一般知識說明。

## 3. Relationship with Use Case
`application_domains` 是粗粒度領域；Use Case 是細粒度的使用者目標。
- Domain：`household`
- Use Case：`USECASE_HANG_OBJECTS`
- Domain：`transportation`
- Use Case：`USECASE_MOVE_OBJECT_TO_LOCATION`

一個 domain 可涵蓋多個 Use Case；一個 Spell 可對應多個 domain 與多個 Use Case。Use Case 的具體適用關係必須另由 Relationship 表達。

## 4. Evidence model
- `canon`：來源明確支持該魔法效果或具體用途。
- `inferred`：由來源支持的效果推導出可能用途。
- `application_domains` 的標籤也應附 `application_domain_evidence`，避免將推論領域誤認為原作設定。
- `confidence`（high/medium/low）僅表示推論強度，不能取代 `canon` / `inferred`。

## 5. Multi-label and granularity rules
- `magic_classification` 僅一個主要值；其他類型如有必要，可在 `classification_notes` 說明，不要把主要類型變成任意多選。
- `functional_effects`、`application_domains` 可多選。
- 避免過度細分同義標籤；若新標籤與既有標籤語意重疊，先考慮 aliases 或階層關係。
- 新增 taxonomy value 必須更新字典、schema、範例與驗證規則。

## 6. Example (illustrative only)
Wingardium Leviosa:
- magic_classification: `charm`
- functional_effects: `levitation`
- application_domains: `household`, `transportation`（需個別標記證據性質）
- difficulty / restriction: 由專案維護者人工標記

此例的領域標籤不代表原作明確展示了每一種具體家務用途。
