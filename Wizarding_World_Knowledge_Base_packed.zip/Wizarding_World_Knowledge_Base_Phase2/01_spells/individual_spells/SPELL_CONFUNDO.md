---
id: SPELL_CONFUNDO
name_en: "Confundo"
name_zh: "混淆咒"
name_zh_status: working_translation
incantation: "Confundo"
magic_classification: charm
functional_effects:
  - effect_id: other
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS, REF_HP_FACT_FILES]
application_domains:
  - combat
  - daily_life
difficulty: medium
restriction: general
taxonomy_version: "1.0"
classification_notes: "分類依本批人工審核；官方資料描述使目標混亂並採取錯誤行動。"
classification_evidence:
  - reference_id: REF_WBJP_SPELLS
    supports: [magic_classification]
    evidence_type: human_reviewed
target: ["person or creature"]
magical_effects:
  - description_en: "Confuses the target and can cause them to make mistaken decisions or act on incorrect assumptions."
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS, REF_HP_FACT_FILES]
references:
  - reference_id: REF_WBJP_SPELLS
    url: "https://www.warnerbros.co.jp/harrypotter/feature/spells-and-charms/"
    source_name: "Warner Bros. Japan — 呪文と魔法"
    source_tier: official
    supports: [magical_effects, functional_effects, incantation]
    accessed_date: "2026-11-01"
  - reference_id: REF_HP_FACT_FILES
    url: "https://www.harrypotter.com/fact-file"
    source_name: "Wizarding World — Harry Potter Fact Files"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: verified
---

# Overview
Confundo 是巫師世界中的具名魔法。Confuses the target and can cause them to make mistaken decisions or act on incorrect assumptions.

## Magical Effects
Confuses the target and can cause them to make mistaken decisions or act on incorrect assumptions.

## Casting Instructions
已知咒語：`Confundo`。
除已明確記載的咒語外，不推定魔杖動作或施法姿勢。

## Applications
此記錄的 application_domains 是知識庫層級的用途歸納，不代表每個領域都曾在原著中直接示範。具體情境關聯應另於 Spell–Use Case Relationship 中標記 canon 或 inferred。

## Restrictions and Limitations
目前僅記錄可由來源支持的效果。若作品未明確交代作用範圍、持續時間或反制方式，不自行補入。

## Related Spells
未在本記錄中建立未經來源支持的 variant 或 counter 關係。若存在本批 50 個以外的相關咒語，僅在後續關係資料中記錄名稱與關係，不另建完整 Spell 記錄。

## Source Notes
分類依本批人工審核；官方資料描述使目標混亂並採取錯誤行動。
繁體中文名稱狀態：`working_translation`。
此筆資料標為 `verified`，表示本次可追溯來源足以支持核心魔法效果；人工分類仍以本專案已核准的 taxonomy 為準。
