---
id: SPELL_EXPECTO_PATRONUM
name_en: "Expecto Patronum"
name_zh: "疾疾，護法現身"
name_zh_status: official_translation
incantation: "Expecto Patronum"
magic_classification: charm
functional_effects:
  - effect_id: summoning
    evidence_status: canon
    reference_ids: [REF_CROWN_TW_GLOSSARY, REF_WBJP_SPELLS]
  - effect_id: protection
    evidence_status: canon
    reference_ids: [REF_CROWN_TW_GLOSSARY, REF_WBJP_SPELLS]
application_domains:
  - defense
difficulty: hard
restriction: general
taxonomy_version: "1.0"
classification_notes: "分類依本批人工審核；官方資料明確描述護法與防禦用途。"
classification_evidence:
  - reference_id: REF_CROWN_TW_GLOSSARY
    supports: [magic_classification]
    evidence_type: human_reviewed
target: ["Dementors; protective guardian"]
magical_effects:
  - description_en: "Conjures a Patronus, a protective magical force used especially against Dementors. A strong positive memory is required; producing a corporeal Patronus is particularly difficult."
    evidence_status: canon
    reference_ids: [REF_CROWN_TW_GLOSSARY, REF_WBJP_SPELLS, REF_WIZARDING_WORLD_GUIDE]
references:
  - reference_id: REF_CROWN_TW_GLOSSARY
    url: "https://www.crown.com.tw/harrypotter/375331_page05.html"
    source_name: "皇冠文化 — 哈利波特中文官網 A to Z"
    source_tier: official
    supports: [name_zh, magical_effects, functional_effects]
    accessed_date: "2026-11-01"
  - reference_id: REF_WBJP_SPELLS
    url: "https://www.warnerbros.co.jp/harrypotter/feature/spells-and-charms/"
    source_name: "Warner Bros. Japan — 呪文と魔法"
    source_tier: official
    supports: [magical_effects, functional_effects, incantation]
    accessed_date: "2026-11-01"
  - reference_id: REF_WIZARDING_WORLD_GUIDE
    url: "https://www.harrypotter.com/features/your-guide-to-the-best-spells-in-harry-potter"
    source_name: "Wizarding World — Your guide to all the best spells in Harry Potter"
    source_tier: official
    supports: [magical_effects, functional_effects, incantation]
    accessed_date: "2026-11-01"
  - reference_id: REF_HP_PATRONUS
    url: "https://www.harrypotter.com/fact-file/spells/the-patronus-charm"
    source_name: "Wizarding World Fact File — The Patronus Charm (Expecto Patronum)"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: verified
---

# Overview
Expecto Patronum 是巫師世界中的具名魔法。Conjures a Patronus, a protective magical force used especially against Dementors. A strong positive memory is required; producing a corporeal Patronus is particularly difficult.

## Magical Effects
Conjures a Patronus, a protective magical force used especially against Dementors. A strong positive memory is required; producing a corporeal Patronus is particularly difficult.

## Casting Instructions
已知咒語：`Expecto Patronum`。
除已明確記載的咒語外，不推定魔杖動作或施法姿勢。

## Applications
此記錄的 application_domains 是知識庫層級的用途歸納，不代表每個領域都曾在原著中直接示範。具體情境關聯應另於 Spell–Use Case Relationship 中標記 canon 或 inferred。

## Restrictions and Limitations
目前僅記錄可由來源支持的效果。若作品未明確交代作用範圍、持續時間或反制方式，不自行補入。

## Related Spells
未在本記錄中建立未經來源支持的 variant 或 counter 關係。若存在本批 50 個以外的相關咒語，僅在後續關係資料中記錄名稱與關係，不另建完整 Spell 記錄。

## Source Notes
分類依本批人工審核；官方資料明確描述護法與防禦用途。
本次補充核對的官方 Wizarding World 來源：Wizarding World Fact File — The Patronus Charm (Expecto Patronum)。
繁體中文名稱狀態：`official_translation`。
此筆資料標為 `verified`，表示本次可追溯來源足以支持核心魔法效果；人工分類仍以本專案已核准的 taxonomy 為準。
