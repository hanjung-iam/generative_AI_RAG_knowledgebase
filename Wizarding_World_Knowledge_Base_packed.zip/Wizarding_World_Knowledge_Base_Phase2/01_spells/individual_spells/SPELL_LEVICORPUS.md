---
id: SPELL_LEVICORPUS
name_en: "Levicorpus"
name_zh: "倒掛金鐘"
name_zh_status: common_translation
incantation: "Levicorpus"
magic_classification: jinx
functional_effects:
  - effect_id: levitation
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS, REF_HP_FACT_FILES]
  - effect_id: suspension
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS, REF_HP_FACT_FILES]
  - effect_id: binding
    evidence_status: inferred
    reference_ids: [REF_WBJP_SPELLS, REF_HP_FACT_FILES]
application_domains:
  - combat
difficulty: medium
restriction: general
taxonomy_version: "1.0"
classification_notes: "分類依本批人工審核；懸吊效果有來源支持，binding 為功能層級推論。"
classification_evidence:
  - reference_id: REF_WBJP_SPELLS
    supports: [magic_classification]
    evidence_type: human_reviewed
target: ["person"]
magical_effects:
  - description_en: "Suspends the target upside down in mid-air, apparently by the ankle. The spell is known to have a non-verbal form."
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS, REF_HP_FACT_FILES]
references:
  - reference_id: REF_WBJP_SPELLS
    url: "https://www.warnerbros.co.jp/harrypotter/feature/spells-and-charms/"
    source_name: "Warner Bros. Japan — 呪文と魔法"
    source_tier: official
    supports: [magical_effects, functional_effects, incantation]
    accessed_date: "2026-11-01"
  - reference_id: REF_HP_FACT_FILES
    url: "https://www.harrypotter.com/fact-file"
    source_name: "Wizarding World — Harry Potter Fact Files"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
  - reference_id: REF_WW_DA_SPELLS
    url: "https://www.harrypotter.com/features/the-most-important-spells-harry-taught-da"
    source_name: "Wizarding World — The most important spells Harry taught Dumbledore’s Army"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
  - reference_id: REF_WW_SNAPE_SPELLS
    url: "https://www.harrypotter.com/features/8-times-the-half-blood-prince-reveals-the-real-snape"
    source_name: "Wizarding World — 8 times the Half-Blood Prince reveals the real Snape"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: verified
---

# Overview
Levicorpus 是巫師世界中的具名魔法。Suspends the target upside down in mid-air, apparently by the ankle. The spell is known to have a non-verbal form.

## Magical Effects
Suspends the target upside down in mid-air, apparently by the ankle. The spell is known to have a non-verbal form.

## Casting Instructions
已知咒語：`Levicorpus`。
除已明確記載的咒語外，不推定魔杖動作或施法姿勢。

## Applications
此記錄的 application_domains 是知識庫層級的用途歸納，不代表每個領域都曾在原著中直接示範。具體情境關聯應另於 Spell–Use Case Relationship 中標記 canon 或 inferred。

## Restrictions and Limitations
目前僅記錄可由來源支持的效果。若作品未明確交代作用範圍、持續時間或反制方式，不自行補入。

## Related Spells
未在本記錄中建立未經來源支持的 variant 或 counter 關係。若存在本批 50 個以外的相關咒語，僅在後續關係資料中記錄名稱與關係，不另建完整 Spell 記錄。

## Source Notes
分類依本批人工審核；懸吊效果有來源支持，binding 為功能層級推論。
本次補充核對的官方 Wizarding World 來源：Wizarding World — The most important spells Harry taught Dumbledore’s Army；Wizarding World — 8 times the Half-Blood Prince reveals the real Snape。
繁體中文名稱狀態：`common_translation`。
此筆資料已由本次補充的官方 Wizarding World 來源支持核心效果；繁體中文名稱若為工作譯名，仍保留相應的 translation status。
