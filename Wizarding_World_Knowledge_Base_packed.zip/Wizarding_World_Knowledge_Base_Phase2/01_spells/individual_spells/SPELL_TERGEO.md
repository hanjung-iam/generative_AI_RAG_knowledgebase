---
id: SPELL_TERGEO
name_en: "Tergeo"
name_zh: "清潔咒"
name_zh_status: working_translation
incantation: "Tergeo"
magic_classification: charm
functional_effects:
  - effect_id: other
    evidence_status: canon
    reference_ids: [REF_HP_FACT_FILES]
application_domains:
  - household
  - daily_life
difficulty: simple
restriction: general
taxonomy_version: "1.0"
classification_notes: "分類依本批人工審核；工作譯名，不與 Scourgify 合併，兩者保留獨立實體。"
classification_evidence:
  - reference_id: REF_HP_FACT_FILES
    supports: [magic_classification]
    evidence_type: human_reviewed
target: ["objects; surfaces; liquids"]
magical_effects:
  - description_en: "Cleans or siphons away substances such as dirt, dust, or liquid from a target surface or object."
    evidence_status: canon
    reference_ids: [REF_HP_FACT_FILES]
references:
  - reference_id: REF_HP_FACT_FILES
    url: "https://www.harrypotter.com/fact-file"
    source_name: "Wizarding World — Harry Potter Fact Files"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
  - reference_id: REF_WW_CLEANING_SPELLS
    url: "https://www.harrypotter.com/features/every-spell-we-wish-we-could-use-for-spring-cleaning-season"
    source_name: "Wizarding World — Every spell we wish we could have for spring-cleaning season"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
  - reference_id: REF_WW_LESSER_SPELLS
    url: "https://www.harrypotter.com/features/a-handy-guide-to-the-lesser-known-spells-in-the-wizarding-world"
    source_name: "Wizarding World — A handy guide to the lesser-known spells in the wizarding world"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: verified
---

# Overview
Tergeo 是巫師世界中的具名魔法。Cleans or siphons away substances such as dirt, dust, or liquid from a target surface or object.

## Magical Effects
Cleans or siphons away substances such as dirt, dust, or liquid from a target surface or object.

## Casting Instructions
已知咒語：`Tergeo`。
除已明確記載的咒語外，不推定魔杖動作或施法姿勢。

## Applications
此記錄的 application_domains 是知識庫層級的用途歸納，不代表每個領域都曾在原著中直接示範。具體情境關聯應另於 Spell–Use Case Relationship 中標記 canon 或 inferred。

## Restrictions and Limitations
目前僅記錄可由來源支持的效果。若作品未明確交代作用範圍、持續時間或反制方式，不自行補入。

## Related Spells
未在本記錄中建立未經來源支持的 variant 或 counter 關係。若存在本批 50 個以外的相關咒語，僅在後續關係資料中記錄名稱與關係，不另建完整 Spell 記錄。

## Source Notes
分類依本批人工審核；工作譯名，不與 Scourgify 合併，兩者保留獨立實體。
本次補充核對的官方 Wizarding World 來源：Wizarding World — Every spell we wish we could have for spring-cleaning season；Wizarding World — A handy guide to the lesser-known spells in the wizarding world。
繁體中文名稱狀態：`working_translation`。
此筆資料已由本次補充的官方 Wizarding World 來源支持核心效果；繁體中文名稱若為工作譯名，仍保留相應的 translation status。
