---
id: SPELL_ARRESTO_MOMENTUM
name_en: "Arresto Momentum"
name_zh: "停止咒"
name_zh_status: working_translation
incantation: "Arresto Momentum"
magic_classification: charm
functional_effects:
  - effect_id: other
    evidence_status: canon
    reference_ids: [REF_HP_FACT_FILES, REF_WBJP_SPELLS]
application_domains:
  - defense
  - transportation
  - daily_life
difficulty: medium
restriction: general
taxonomy_version: "1.0"
classification_notes: "分類依本批人工審核；官方 Fact File 描述減速與停止動量。"
classification_evidence:
  - reference_id: REF_HP_FACT_FILES
    supports: [magic_classification]
    evidence_type: human_reviewed
target: ["moving object or person"]
magical_effects:
  - description_en: "Slows or stops the momentum of a moving object or person, such as a falling individual."
    evidence_status: canon
    reference_ids: [REF_HP_FACT_FILES, REF_WBJP_SPELLS]
references:
  - reference_id: REF_HP_FACT_FILES
    url: "https://www.harrypotter.com/fact-file"
    source_name: "Wizarding World — Harry Potter Fact Files"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
  - reference_id: REF_WBJP_SPELLS
    url: "https://www.warnerbros.co.jp/harrypotter/feature/spells-and-charms/"
    source_name: "Warner Bros. Japan — 呪文と魔法"
    source_tier: official
    supports: [magical_effects, functional_effects, incantation]
    accessed_date: "2026-11-01"
  - reference_id: REF_HP_ARRESTO
    url: "https://www.harrypotter.com/fact-file/spells/the-braking-charm"
    source_name: "Wizarding World Fact File — The Braking Charm (Arresto Momentum)"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: verified
---

# Overview
Arresto Momentum 是巫師世界中的具名魔法。Slows or stops the momentum of a moving object or person, such as a falling individual.

## Magical Effects
Slows or stops the momentum of a moving object or person, such as a falling individual.

## Casting Instructions
已知咒語：`Arresto Momentum`。
除已明確記載的咒語外，不推定魔杖動作或施法姿勢。

## Applications
此記錄的 application_domains 是知識庫層級的用途歸納，不代表每個領域都曾在原著中直接示範。具體情境關聯應另於 Spell–Use Case Relationship 中標記 canon 或 inferred。

## Restrictions and Limitations
目前僅記錄可由來源支持的效果。若作品未明確交代作用範圍、持續時間或反制方式，不自行補入。

## Related Spells
未在本記錄中建立未經來源支持的 variant 或 counter 關係。若存在本批 50 個以外的相關咒語，僅在後續關係資料中記錄名稱與關係，不另建完整 Spell 記錄。

## Source Notes
分類依本批人工審核；官方 Fact File 描述減速與停止動量。
本次補充核對的官方 Wizarding World 來源：Wizarding World Fact File — The Braking Charm (Arresto Momentum)。
繁體中文名稱狀態：`working_translation`。
此筆資料標為 `verified`，表示本次可追溯來源足以支持核心魔法效果；人工分類仍以本專案已核准的 taxonomy 為準。
