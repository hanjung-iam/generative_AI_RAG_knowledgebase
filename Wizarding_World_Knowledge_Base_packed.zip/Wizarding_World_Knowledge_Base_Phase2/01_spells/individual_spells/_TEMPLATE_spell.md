---
id: SPELL_REPLACE_WITH_ID
name_en: "English canonical name"
# name_zh: "繁體中文名稱"
# name_ja: "日本語名"
# aliases: []
# incantation: "Only if verified"
magic_classification: unclassified
functional_effects:
  - effect_id: other
    evidence_status: canon
    reference_ids: [REF_REPLACE_WITH_ID]
# application_domains:
#   - daily_life
# application_domain_evidence:
#   - domain_id: daily_life
#     evidence_status: inferred
#     reference_ids: [REF_REPLACE_WITH_ID]
#     reasoning: "Explain the inference."
difficulty: simple
restriction: general
taxonomy_version: "1.0"
# classification_notes: ""
# classification_evidence:
#   - reference_id: REF_REPLACE_WITH_ID
#     supports: magic_classification
# target: []
# wand_movement: ""
# casting_requirements: []
magical_effects:
  - description_en: "Evidence-supported description."
    # description_zh: ""
    # description_ja: ""
    evidence_status: canon
    reference_ids: [REF_REPLACE_WITH_ID]
# limitations: []
# side_effects: []
# counter_spells: []
# variant_of: SPELL_PARENT_ID
# related_spell_ids: []
# entity_resolution_notes: ""
references:
  - reference_id: REF_REPLACE_WITH_ID
    url: "https://..."
    source_name: "Source title"
    source_tier: official
    supports: [magical_effects]
    accessed_date: "YYYY-MM-DD"
status: draft
---

# Overview
以自己的文字簡述魔法，不大段複製來源。

## Magical Effects
記錄來源明確支持的效果，並與 functional_effects 標籤一致。

## Casting Instructions
只有來源有記載才填寫咒語、魔杖動作與施法條件。

## Applications
列出來源明確支持的用途。推論用途另建 Relationship，標記 inferred。

## Restrictions and Limitations
僅記錄有證據支持的限制、副作用或反制方式。

## Related Spells
區分 variant、counter、similar_function 或其他 related 關係。

## Source Notes
說明來源支持哪些資訊，以及來源間是否有差異。
