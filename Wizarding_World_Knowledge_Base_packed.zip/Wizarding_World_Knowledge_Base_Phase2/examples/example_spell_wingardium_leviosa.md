---
id: SPELL_WINGARDIUM_LEVIOSA
name_en: Wingardium Leviosa
name_zh: 飄浮咒
name_ja: ウィンガーディアム・レビオーサ
incantation: Wingardium Leviosa
magic_classification: charm
functional_effects:
  - effect_id: levitation
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS]
application_domains:
  - household
  - transportation
application_domain_evidence:
  - domain_id: household
    evidence_status: inferred
    reference_ids: [REF_WBJP_SPELLS]
    reasoning: "由物體漂浮效果推導可能的居家應用；不表示原作明確展示晾衣用途。"
  - domain_id: transportation
    evidence_status: inferred
    reference_ids: [REF_WBJP_SPELLS]
    reasoning: "漂浮可能協助移動物體，但不代表可精準控制所有搬運流程。"
difficulty: simple
restriction: general
taxonomy_version: "1.0"
magical_effects:
  - description_en: "Causes an object to levitate."
    description_zh: "使物體漂浮。"
    evidence_status: canon
    reference_ids: [REF_WBJP_SPELLS]
references:
  - reference_id: REF_WBJP_SPELLS
    url: "https://www.warnerbros.co.jp/harrypotter/feature/spells-and-charms/"
    source_name: "Warner Bros. Japan — Spells and Charms"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: draft
---

# Overview
飄浮咒可使物體漂浮。

## Magical Effects
核心效果為使物體漂浮。此範例將「漂浮」標記為 canon 功能效果。

## Applications
家務與搬運僅作 inferred 高層級應用示範；晾衣服等具體目標仍須由 Relationship 表達。

## Source Notes
示範資料，正式收錄前需人工核對來源、翻譯與分類。
