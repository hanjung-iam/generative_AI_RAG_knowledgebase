---
id: SPELL_LUMOS
name_en: Lumos
magic_classification: charm
functional_effects:
  - effect_id: illumination
    evidence_status: canon
    reference_ids: [REF_WIZARDING_WORLD]
application_domains:
  - daily_life
  - exploration
application_domain_evidence:
  - domain_id: daily_life
    evidence_status: inferred
    reference_ids: [REF_WIZARDING_WORLD]
    reasoning: "照明效果可推導出日常使用領域。"
  - domain_id: exploration
    evidence_status: inferred
    reference_ids: [REF_WIZARDING_WORLD]
    reasoning: "照明效果可推導出探索昏暗環境的用途。"
difficulty: simple
restriction: general
taxonomy_version: "1.0"
magical_effects:
  - description_en: "Produces light from the wand."
    evidence_status: canon
    reference_ids: [REF_WIZARDING_WORLD]
references:
  - reference_id: REF_WIZARDING_WORLD
    url: "https://www.harrypotter.com/features/your-guide-to-the-best-spells-in-harry-potter"
    source_name: "Wizarding World — Your guide to the best spells"
    source_tier: official
    supports: [magical_effects, functional_effects]
    accessed_date: "2026-11-01"
status: draft
---

# Overview
Lumos 是具名的照明魔法。

## Magical Effects
產生魔杖光源。此處只示範 schema 結構。

## Applications
日常照明與探索環境標記為 inferred domain，待依專案來源政策審核。
