---
id: SPELL_LUMOS_MAXIMA
name_en: Lumos Maxima
magic_classification: charm
functional_effects:
  - effect_id: illumination
    evidence_status: canon
    reference_ids: [REF_WIZARDING_WORLD]
application_domains:
  - daily_life
  - exploration
application_domain_evidence:
  - domain_id: daily_life
    evidence_status: inferred
    reference_ids: [REF_WIZARDING_WORLD]
    reasoning: "照明效果可推導出日常使用領域。"
difficulty: medium
restriction: general
taxonomy_version: "1.0"
variant_of: SPELL_LUMOS
references:
  - reference_id: REF_WIZARDING_WORLD
    url: "https://www.harrypotter.com/features/your-guide-to-the-best-spells-in-harry-potter"
    source_name: "Wizarding World — Your guide to the best spells"
    source_tier: official
    supports: [magical_effects]
    accessed_date: "2026-11-01"
status: draft
---

# Overview
Lumos Maxima 作為具名魔法變體的資料建模示範。

## Source Notes
`variant_of` 只可在來源明確支持兩者變體關係時保留。本示範目前為 draft，正式資料匯入前須核實該關係及具體效果差異。
