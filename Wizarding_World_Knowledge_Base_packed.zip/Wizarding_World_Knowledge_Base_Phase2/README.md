# Wizarding World Spell Assistant — Knowledge Base
Version: Phase 2 integrated release

## Project purpose
本知識庫支援「哈利波特魔法咒語情境式 RAG 推薦助理」。系統從使用者自然語言情境辨識目標與所需效果，檢索具名魔法，並依證據區分原作／來源明確支持（`canon`）與功能推論（`inferred`）。

不得把推論用途描述成原作已確認的事實；不得補造咒語、魔法效果、施法方式、副作用或限制。

## Confirmed project decisions
- 收錄範圍：各類型、具名且可辨識的魔法；不要求一定知道 incantation。
- 初始收錄策略：平衡涵蓋不同魔法類型。
- 主要來源：Wizarding World、Warner Bros. Japan；Harry Potter Wiki 僅作補充。
- 語言：英文、繁體中文、日文。
- 難度：`simple` / `medium` / `hard`，由維護者人工標記。
- 限制：`general` / `restricted`，由維護者人工標記，與難度獨立。
- 缺乏證據的選填欄位直接省略。
- 情境關聯允許 `canon` 與 `inferred`，必須明確區分。
- 推薦數量依問題複雜度動態調整。
- 回答語氣依難度採角色特質啟發的原創風格；restricted 額外加警示。

## Phase 2 taxonomy
Spell classification 採多維度設計：
1. `magic_classification`：魔法性質／傳統類型，單一主要分類。
2. `functional_effects`：魔法實際產生的效果，可多選。
3. `application_domains`：高層級應用領域，可多選。
4. `difficulty`：人工難度標籤。
5. `restriction`：人工限制標籤。

`Use Case` 保留為獨立實體，描述具體使用者目標；不可與 `application_domains` 合併。

## Directory
```text
Wizarding_World_Knowledge_Base/
├── README.md
├── config/
│   ├── knowledge_schema.md
│   ├── category_definitions.md
│   ├── taxonomy_specification.md
│   ├── magic_classification.json
│   ├── functional_effects.json
│   ├── application_domains.json
│   ├── entity_resolution_rules.md
│   ├── translation_mapping.json
│   ├── id_registry.json
│   └── validation_checklist.md
├── 01_spells/
│   ├── individual_spells/_TEMPLATE_spell.md
│   ├── spell_relationships/
│   └── spell_types/
├── 02_use_cases/
│   ├── daily_life/
│   ├── household/
│   ├── transportation/
│   ├── protection/
│   ├── organization/
│   └── other_scenarios/_TEMPLATE_use_case.md
├── 03_relationships/
│   ├── spell_use_case_relationships.json
│   └── relationship_types.json
├── 04_indexes/
│   ├── spells_index.json
│   ├── use_cases_index.json
│   └── relationships_index.json
├── rag/
│   └── embedding_config.json
└── examples/
    ├── example_spell_wingardium_leviosa.md
    ├── example_spell_lumos.md
    ├── example_spell_lumos_maxima.md
    ├── example_use_case_hanging_objects.md
    └── example_relationships.json
```

## Source hierarchy
- `official`: Wizarding World / Warner Bros. official sources.
- `supplementary`: Harry Potter Wiki and other secondary references.
- `other`: 其他經審核來源。

官方來源優先。來源衝突時保留差異與來源註記，不自行拼湊成單一確定結論。

## Maintenance workflow
1. 搜尋現有名稱與 ID，確認是否已存在實體。
2. 依 `entity_resolution_rules.md` 判定 Translation、Alias、Variant 或 Related。
3. 建立或更新 Spell record。
4. 指定魔法性質、功能效果、應用領域、難度與限制。
5. 將具體使用者目標建成 Use Case。
6. 建立 Spell–Use Case Relationship，標記 `canon` 或 `inferred`。
7. 更新 translation mapping、ID registry 與 indexes。
8. 執行 validation checklist。
9. 只有 `verified` 的紀錄可進正式檢索資料集；draft 可用於內部審查。

## Data governance
- ID 建立後不可因翻譯、拼寫或分類變動而更改。
- 初始 MVP 可先以約 30–100 筆為收錄規模參考，但不得在 schema 或程式中設硬上限。
- 原始 Markdown / JSON 是 source of truth；RAG 文件與向量索引均為衍生產物。
- `canon` / `inferred`、來源引用與實體關係必須在 RAG chunk metadata 中保留。
